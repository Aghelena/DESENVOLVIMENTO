import ProductForm from '../components/ProductForm';

function AddProduct() {
  return (
    <div>
      <h1> LIVROS </h1>
      <ProductForm />
    </div>
  );
}

export default AddProduct;
